-- This Script is Part of the Prometheus Obfuscator by levno-710
--
-- steps.lua
--
-- This Script provides a collection of obfuscation steps.

return {
	WrapInFunction = require("prometheus.steps.WrapInFunction"),
	SplitStrings = require("prometheus.steps.SplitStrings"),
	Vmify = require("prometheus.steps.Vmify"),
	ConstantArray = require("prometheus.steps.ConstantArray"),
	ProxifyLocals = require("prometheus.steps.ProxifyLocals"),
	AntiTamper = require("prometheus.steps.AntiTamper"),
	EncryptStrings = require("prometheus.steps.EncryptStrings"),
	NumbersToExpressions = require("prometheus.steps.NumbersToExpressions"),
	AddVararg = require("prometheus.steps.AddVararg"),
	WatermarkCheck = require("prometheus.steps.WatermarkCheck"),
	AzureVM = require("prometheus.steps.AzureVM"),
	SafeRetryWrapper = require("prometheus.steps.SafeRetryWrapper"),
	ControlFlowFlattening = require("prometheus.steps.ControlFlowFlattening"),
	DeepControlFlowFlattening = require("prometheus.steps.DeepControlFlowFlattening"),
	MixedBooleanArithmetic = require("prometheus.steps.MixedBooleanArithmetic"),
	OpaquePredicates = require("prometheus.steps.OpaquePredicates"),
}